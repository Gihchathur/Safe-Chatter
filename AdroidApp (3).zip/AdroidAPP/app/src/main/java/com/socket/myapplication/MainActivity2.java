package com.socket.myapplication;

//import android.support.v7.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;


public class MainActivity2 extends AppCompatActivity {


    private String Username = "User";
    private ImageView profile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        profile = findViewById(R.id.profilePhoto);

        Username = getIntent().getStringExtra("username");
        TextView tvName = (TextView)findViewById(R.id.textbox1);
        tvName.setText(""+Username);

        String Str= "https://firebasestorage.googleapis.com/v0/b/healthy-buddy1995.appspot.com/o/Images%2F"+Username+"?alt=media&token=ce016851-fae0-485e-96ba-ea948724bbac";
        Picasso.get().load(Str).into(profile);

        Button buttonOne = findViewById(R.id.button1);
        buttonOne.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Username = getIntent().getStringExtra("username");
                TextView tvName = (TextView)findViewById(R.id.textbox1);
                tvName.setText(""+Username);
                Intent intent = new Intent(MainActivity2.this, ChatmenutPage.class);
                intent.putExtra("username", tvName.getText().toString());
                startActivity(intent);
            }
        });


        Button buttontwo = findViewById(R.id.button2);
        buttontwo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Username = getIntent().getStringExtra("username");
                TextView tvName = (TextView)findViewById(R.id.textbox1);
                tvName.setText(Username);
                Intent intent = new Intent(MainActivity2.this, RequestPage.class);
                intent.putExtra("username", tvName.getText().toString());
                startActivity(intent);
            }
        });

        Button buttontre = findViewById(R.id.button7);
        buttontre.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Username = getIntent().getStringExtra("username");
                TextView tvName = (TextView)findViewById(R.id.textbox1);
                tvName.setText(Username);
                Intent intent = new Intent(MainActivity2.this, ChatmenutPageGroup.class);
                intent.putExtra("username", tvName.getText().toString());
                startActivity(intent);
            }
        });
    }


}