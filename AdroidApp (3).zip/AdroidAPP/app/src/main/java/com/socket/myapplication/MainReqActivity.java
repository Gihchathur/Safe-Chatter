package com.socket.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class MainReqActivity extends AppCompatActivity {


    String name1,name2;
    Button bt1,bt2;
    TextView text;
    DatabaseReference ref;
    Member member;
    ImageView profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_req);

        profile=findViewById(R.id.imageView2);

        name1 = getIntent().getStringExtra("name1");
        name2 = getIntent().getStringExtra("name2");

        bt1=findViewById(R.id.button3);
        bt2=findViewById(R.id.button5);
        text=findViewById(R.id.textView3);

        text.setText(name1);

        member=new Member();

        String Str= "https://firebasestorage.googleapis.com/v0/b/my-application-64210.appspot.com/o/Images%2F"+name1+".png?alt=media&token=ce016851-fae0-485e-96ba-ea948724bbac";
        Picasso.get().load(Str).into(profile);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                DatabaseReference db_node = FirebaseDatabase.getInstance().getReference().child(name2);
                db_node.removeValue();


                ref = FirebaseDatabase.getInstance().getReference().child(name2+"new");

               /* member.setName1(text1.getText().toString().trim());
                member.setName2(text2.getText().toString().trim());
                refgihan.push().setValue(member);*/
                member.setName1(name1);
                member.setName2(name2);
                member.setCheck("2");
                ref.push().setValue(member);
                Toast.makeText(MainReqActivity.this,"Request Accepted",Toast.LENGTH_LONG).show();


                ref = FirebaseDatabase.getInstance().getReference().child(name1+"new");

               /* member.setName1(text1.getText().toString().trim());
                member.setName2(text2.getText().toString().trim());
                refgihan.push().setValue(member);*/
                member.setName1(name2);
                member.setName2(name1);
                member.setCheck("2");
                ref.push().setValue(member);

                Intent intent = new Intent(MainReqActivity.this, RequestPage.class);
                intent.putExtra("username",name2);
                startActivity(intent);


            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                DatabaseReference db_node = FirebaseDatabase.getInstance().getReference().child(name2);
                db_node.removeValue();


                Intent intent = new Intent(MainReqActivity.this, RequestPage.class);
                intent.putExtra("username",name2);
                startActivity(intent);
            }
        });




    }
}