package com.socket.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity3 extends AppCompatActivity {

    Button btn;
    EditText searchTetxt;
    RecyclerView recyclerView;
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_main);

        ref = FirebaseDatabase.getInstance().getReference().child("Member");
        btn = findViewById(R.id.button4);
        searchTetxt= findViewById(R.id.textView7);
        recyclerView = findViewById(R.id.mylist);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //firebaseSearch();
            }
        });



    }




    public class UserViewHolder extends RecyclerView.ViewHolder {
        View mView;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            mView = itemView;
        }
    }

}