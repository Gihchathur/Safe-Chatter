package com.socket.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivityoldgroup extends AppCompatActivity {

    Button btn;
    EditText text1,text2;
    DatabaseReference ref;
    Member member;
    String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_group_main);

        Username = getIntent().getStringExtra("username");

        btn = findViewById(R.id.button4);
        text2=findViewById(R.id.textView7);

        member=new Member();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                name = text2.getText().toString();

                ref = FirebaseDatabase.getInstance().getReference().child(Username+"Group");

               /* member.setName1(text1.getText().toString().trim());
                member.setName2(text2.getText().toString().trim());
                refgihan.push().setValue(member);*/
               member.setName1(Username);
               member.setName2(text2.getText().toString().trim());
               member.setCheck("3");
               ref.push().setValue(member);
               Toast.makeText(MainActivityoldgroup.this,"Group Created",Toast.LENGTH_LONG).show();

                Intent Intent = new Intent(MainActivityoldgroup.this, MainActivityoldAdd.class);
                Intent.putExtra("name1", Username);
                Intent.putExtra("name2", text2.getText().toString().trim());
                startActivity(Intent);

            }
        });

    }


}