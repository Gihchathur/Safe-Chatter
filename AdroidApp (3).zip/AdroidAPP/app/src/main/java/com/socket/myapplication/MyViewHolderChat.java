package com.socket.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class MyViewHolderChat extends RecyclerView.ViewHolder {

    TextView name1,name2;
    String check;
    LinearLayout layout;
    ImageView profile;
    public MyViewHolderChat(@NonNull View itemView) {
        super(itemView);

        name2=itemView.findViewById(R.id.nameDoc);
        name1=itemView.findViewById(R.id.hometownDoc);
        layout= itemView.findViewById(R.id.layout);
        profile= itemView.findViewById(R.id.imageView3);


    }
}
