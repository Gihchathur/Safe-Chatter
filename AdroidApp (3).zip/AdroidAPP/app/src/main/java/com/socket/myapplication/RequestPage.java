package com.socket.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

//import android.support.v7.app.AppCompatActivity;


public class RequestPage extends AppCompatActivity {


    private String Username = "User";
    DatabaseReference ref;
    RecyclerView recyclerView;

    private FirebaseRecyclerOptions<Member> options;
    private FirebaseRecyclerAdapter<Member, MyViewHolder> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_page);

        Username = getIntent().getStringExtra("username");


        TextView tvName = (TextView) findViewById(R.id.textbox1);
        tvName.setText("   " );


        Button buttonOne = findViewById(R.id.button6);
        buttonOne.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Username = getIntent().getStringExtra("username");
                TextView tvName = (TextView) findViewById(R.id.textbox1);
                Intent intent = new Intent(RequestPage.this, MainActivityold.class);
                intent.putExtra("username", Username.toString());
                startActivity(intent);
            }
        });

        Button buttontwo= findViewById(R.id.button1);
        buttontwo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Username = getIntent().getStringExtra("username");
                TextView tvName = (TextView) findViewById(R.id.textbox1);
                Intent intent = new Intent(RequestPage.this, MainActivityoldgroup.class);
                intent.putExtra("username", Username.toString());
                startActivity(intent);
            }
        });




        ref = FirebaseDatabase.getInstance().getReference().child(Username);
        recyclerView = findViewById(R.id.docList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //String quary ="Amal";
        //Query firebaseSearchQuery = ref.orderByChild("chari");
        //options = new FirebaseRecyclerOptions.Builder<Member>().setQuery(ref, Member.class).build();
        options = new FirebaseRecyclerOptions.Builder<Member>().setQuery(ref, Member.class).build();



        adapter = new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {

                    holder.name1.setText("Friend Request From ");
                    holder.name2.setText(" " + model.getName1());
                    holder.check = model.getCheck();

                    String Str= "https://firebasestorage.googleapis.com/v0/b/my-application-64210.appspot.com/o/Images%2F"+model.getName1()+".png?alt=media&token=ce016851-fae0-485e-96ba-ea948724bbac";
                    Picasso.get().load(Str).into(holder.profile);


                if(position % 2 == 1){
                    holder.itemView.setBackgroundColor(Color.parseColor("#efefef"));
                }
                    holder.layout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            Intent Intent = new Intent(RequestPage.this, MainReqActivity.class);
                            Intent.putExtra("name1", model.getName1());
                            Intent.putExtra("name2", model.getName2());
                        startActivity(Intent);
                        }
                    });



            }


                @NonNull
                @Override
                public MyViewHolder onCreateViewHolder (@NonNull ViewGroup parent,int viewType){
                    View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout, parent, false);
                    return new MyViewHolder(v);
                }
            };

        adapter.startListening();
        recyclerView.setAdapter(adapter);
        //firebaseSearch("Amal");


    }


    private void firebaseSearch(String searchText) {
        String quary = searchText.toLowerCase();
        Query firebaseSearchQuery = ref.orderByChild("Member").startAt(quary).endAt(quary + "\uf8ff");
        options = new FirebaseRecyclerOptions.Builder<Member>().setQuery(firebaseSearchQuery, Member.class).build();


        adapter = new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {


                holder.name1.setText(" " + model.getName1());
                holder.name2.setText(" " + model.getName2());
                holder.check = model.getCheck();

                holder.layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent Intent = new Intent(RequestPage.this, ChatActivity2.class);
                        startActivity(Intent);
                    }
                });

            }

            @NonNull
            @Override
            public MyViewHolder onCreateViewHolder (@NonNull ViewGroup parent,int viewType){
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout, parent, false);
                return new MyViewHolder(v);
            }
        };

        adapter.startListening();
        recyclerView.setAdapter(adapter);


    }

}