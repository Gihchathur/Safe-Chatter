package com.socket.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivityoldAdd extends AppCompatActivity {

    Button btn,btncls;
    EditText text1,text2;
    DatabaseReference ref;
    Member member;
    String Username,Groupname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_group_add_main);

        Username = getIntent().getStringExtra("name1");
        Groupname=getIntent().getStringExtra("name2");


        btn = findViewById(R.id.button4);
        btncls=findViewById(R.id.button8);
        text2=findViewById(R.id.textView7);

        member=new Member();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                name = text2.getText().toString();

                ref = FirebaseDatabase.getInstance().getReference().child(name+"Group");

               /* member.setName1(text1.getText().toString().trim());
                member.setName2(text2.getText().toString().trim());
                refgihan.push().setValue(member);*/
               member.setName1(text2.getText().toString().trim());
               member.setName2(Groupname);
               member.setCheck("3");
               ref.push().setValue(member);
               Toast.makeText(MainActivityoldAdd.this,text2.getText().toString().trim()+" Added",Toast.LENGTH_LONG).show();

            }
        });

        btncls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivityoldAdd.this, MainActivity2.class);
                intent.putExtra("username", Username);
                startActivity(intent);

            }
        });



    }


}