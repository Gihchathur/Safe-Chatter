package com.socket.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivityold extends AppCompatActivity {

    Button btn;
    EditText text1,text2;
    DatabaseReference ref;
    Member member;
    String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_main);

        Username = getIntent().getStringExtra("username");

        btn = findViewById(R.id.button4);
        text2=findViewById(R.id.textView7);

        member=new Member();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name;
                name = text2.getText().toString();

                ref = FirebaseDatabase.getInstance().getReference().child(name);

               /* member.setName1(text1.getText().toString().trim());
                member.setName2(text2.getText().toString().trim());
                refgihan.push().setValue(member);*/
               member.setName1(Username);
               member.setName2(text2.getText().toString().trim());
               member.setCheck("1");
               ref.push().setValue(member);
               Toast.makeText(MainActivityold.this,"Data Inserted",Toast.LENGTH_LONG).show();

            }
        });

    }


}