package com.socket.myapplication;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;


import com.chaos.view.PinView;

//import android.support.v7.app.AppCompatActivity;
//import android.support.constraint.ConstraintLayout;

public class MainActivityOPT extends AppCompatActivity implements View.OnClickListener {

    private PinView pinView;
    private Button next;
    private TextView topText, textU;
    private EditText userName, userPhone;
    private ConstraintLayout first, second;
    String verficationcodeBySystem;
    String message = "hello gihan";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*requestWindowFeature(1);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);*/
        setContentView(R.layout.activity_main3);

        topText = findViewById(R.id.topText);
        pinView = findViewById(R.id.pinView);
        next = findViewById(R.id.button);
        userName = findViewById(R.id.username);
        userPhone = findViewById(R.id.userPhone);
        first = findViewById(R.id.first_step);
        second = findViewById(R.id.secondStep);
        textU = findViewById(R.id.textView_noti);
        first.setVisibility(View.VISIBLE);

        next.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        String phone = userPhone.getText().toString();
        sendVarificationToUser(phone);

        if (next.getText().equals("Let's go!")) {
            String name = userName.getText().toString();
            //String phone = userPhone.getText().toString();

            if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(phone)) {

                sendVarificationToUser(phone);
                next.setText("Verify");
                first.setVisibility(View.GONE);
                second.setVisibility(View.VISIBLE);
                topText.setText(" ");
            } else {
                Toast.makeText(MainActivityOPT.this, "Please enter the details", Toast.LENGTH_SHORT).show();
            }
        } else if (next.getText().equals("Verify")) {

            //String phone = userPhone.getText().toString();
            sendVarificationToUser(phone);


            String OTP = pinView.getText().toString();
            if (OTP.equals("1234")) {
                pinView.setLineColor(Color.GREEN);
                textU.setText("OTP Verified");
                textU.setTextColor(Color.GREEN);
                next.setText("Next");
                final Handler handler = new Handler();
                next.setText("Loading..");
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        next.setText("Loading..");
                        Intent i = new Intent(MainActivityOPT.this, AddUserActivity.class);
                        MainActivityOPT.this.startActivity(i);
                    }
                }, 3000);


            } else {
                pinView.setLineColor(Color.RED);
                textU.setText("Incorrect OTP");
                textU.setTextColor(Color.RED);
            }
        }

    }

    void sendVarificationToUser(String phone)
    {
        /*HttpClient httpclient = new DefaultHttpClient();
        String ACCOUNT_SID = "AC2a23dae705d29bd26946308d2254e098";
        String AUTH_TOKEN = "05054b601dec1d1892f78780b98b1c67";

        HttpPost httppost = new HttpPost(
                "https://api.twilio.com/2010-04-01/Accounts/{ACCOUNT_SID}/SMS/Messages");
        String base64EncodedCredentials = "Basic "
                + Base64.encodeToString(
                (ACCOUNT_SID + ":" + AUTH_TOKEN).getBytes(),
                Base64.NO_WRAP);

        httppost.setHeader("Authorization",
                base64EncodedCredentials);
        try {

            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("From",
                    "+94713693073"));
            nameValuePairs.add(new BasicNameValuePair("To",
                    "+94762143882"));
            nameValuePairs.add(new BasicNameValuePair("Body",
                    "Welcome to Twilio"));

            httppost.setEntity(new UrlEncodedFormEntity(
                    nameValuePairs));

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            System.out.println("Entity post is: "
                    + EntityUtils.toString(entity));


        } catch (ClientProtocolException e) {

        } catch (IOException e) {

        }*/
    }








}
